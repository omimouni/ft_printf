/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/26 19:23:07 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/29 17:55:57 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_p1_1(void)
{
	g_ubl = l_pbigger() - g_plarg;
	g_uy = g_parg;
	if (g_nw < 0 && check_point() == 0)
	{
		ft_pputnbr(g_parg);
		while (g_ubl > 0)
		{
			ft_putchar(' ');
			g_ubl--;
		}
	}
	else if (g_nw < 0 && check_point() != 0 && -g_nw > g_np)
	{
		print_p1_2();
		while (g_ubl > 0)
		{
			ft_putchar(' ');
			g_ubl--;
		}
	}
}

void	print_p1_2(void)
{
	if (g_plarg <= g_np)
		g_ux = g_np - g_plarg;
	ft_pputnbr(g_parg);
}

int		l_pbigger(void)
{
	int l;
	int nw;

	l = 1;
	nw = g_nw;
	if (g_nw < 0)
		nw = nw * (-1);
	if (g_plarg > nw && g_plarg > g_np)
		l = l * g_plarg;
	else if (g_np > nw && g_np > g_plarg)
		l = l * g_np;
	else
		l = l * nw;
	return (l);
}
