/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils4.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/29 02:24:21 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 03:59:21 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int		check_point(void)
{
	int i;

	i = 0;
	while (g_str[i])
	{
		if (g_str[i] == '.')
			return (1);
		i++;
	}
	return (0);
}

int		check_etoile(void)
{
	int i;

	i = 0;
	while (g_str[i])
	{
		if (g_str[i] == '*')
			return (1);
		i++;
	}
	return (0);
}

int		nb_etoile(void)
{
	int i;
	int l;

	i = 0;
	l = 0;
	while (g_str[i])
	{
		if (g_str[i] == '*')
			l++;
		i++;
	}
	return (l);
}
