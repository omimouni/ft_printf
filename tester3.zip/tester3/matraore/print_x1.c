/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/26 19:23:07 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/31 20:35:02 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_x1_1(void)
{
	g_ubl = l_ubigger() - g_ularg;
	g_uy = g_uarg;
	if (g_nw < 0 && check_point() == 0)
	{
		ft_xputnbr(g_uarg);
		while (g_ubl > 0)
		{
			ft_putchar(' ');
			g_ubl--;
		}
	}
	else if (g_nw < 0 && check_point() != 0 && -g_nw > g_np)
	{
		print_x1_2();
		while (g_ubl > 0)
		{
			ft_putchar(' ');
			g_ubl--;
		}
	}
}

void	print_x1_2(void)
{
	if (g_ularg <= g_np)
		g_ux = g_np - g_ularg;
	while (g_ux > 0 && g_ularg < g_np)
	{
		ft_putchar('0');
		g_ux--;
		g_ubl--;
	}
	if (g_uonp == 0 && g_uarg == 0)
		g_ubl++;
	else
	{
		ft_xputnbr(g_uarg);
	}
}

void	xetoile(va_list g_args)
{
	if (check_etoile() == 1 && check_point() == 0)
	{
		g_nw = va_arg(g_args, int);
		xetoile3();
	}
	else if (check_etoile() == 1 && check_point() != 0)
	{
		if (nb_etoile() == 2)
		{
			g_nw = va_arg(g_args, int);
			g_np = va_arg(g_args, int);
		}
		else if (nb_etoile() == 1)
		{
			if (g_str[0] == '*' || (g_str[1] == '*' && (g_str[0] == '-' ||
							g_str[0] == '0')))
				g_nw = va_arg(g_args, int);
			else
				g_np = va_arg(g_args, int);
		}
	}
	g_uarg = va_arg(g_args, unsigned int);
	xetoile2();
}

void	xetoile2(void)
{
	g_uonp = g_np;
	if (g_nw == 0 && g_np == 0 && g_uarg == 0)
		g_exc = 1;
	if (check_etoile() == 1 && g_np < 0)
	{
		g_uneg = 1;
		g_np = 0;
	}
	if (g_str[0] == '0')
		g_uzero = 1;
	if (g_nw == 0 && ft_strlen(g_str) != 0 && check_point() == 0 &&
	(g_w[0] == '-' || g_w[0] == '0'))
		g_uexz = 1;
	if (ft_strlen(g_str) == 0 || g_uexz == 1)
		g_exc = 0;
}

void	xetoile3(void)
{
	if (g_nw == 0)
		g_uexz = 1;
	if (g_nw == 0 && g_uarg == 0)
		g_exc = 1;
}
