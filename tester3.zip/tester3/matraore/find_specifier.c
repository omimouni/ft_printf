/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_specifier.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/27 06:30:45 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/29 03:44:21 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	find_specifier(char *fmt, va_list g_args)
{
	int i;
	int j;

	i = g_i;
	j = 0;
	g_prc_r = 0;
	while (fmt[i])
	{
		if (specifiers(fmt[i]) == 1)
		{
			g_j = i;
			g_name_s = fmt[i];
			collect_infos(fmt, g_args);
			break ;
		}
		i++;
	}
	print_str(fmt);
}

void	print_str(char *fmt)
{
	int i;

	i = g_j + 1;
	while (fmt[i] != '%' && fmt[i])
	{
		ft_putchar(fmt[i]);
		i++;
	}
}
