/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/24 22:28:32 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/31 20:26:11 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_x(void)
{
	g_ularg = lx_arg(g_uarg);
	g_nnw = g_nw;
	g_l = l_ubigger() - g_ularg;
	if (g_nw < 0)
		g_nnw = -g_nnw;
	print_x2();
	if (g_nw > 0 && (check_point() == 0 || g_uneg == 1))
	{
		while (g_l > 0 && g_ularg < g_nw)
		{
			(*g_str == '0' || g_uzero == 1) ? ft_putchar('0') : ft_putchar(' ');
			g_l--;
		}
		ft_xputnbr(g_uarg);
	}
	else if (g_nw > 0 && check_point() != 0 && g_nw > g_np)
		print_x3();
	print_x1_1();
}

void	print_x2(void)
{
	if (ft_strlen(g_str) == 0 || g_uexz == 1)
	{
		ft_xputnbr(g_uarg);
	}
	if (check_point() != 0 && g_np >= g_nnw)
	{
		while (g_l > 0 && g_ularg < g_np)
		{
			ft_putchar('0');
			g_l--;
		}
		ft_xputnbr(g_uarg);
	}
}

void	print_x3(void)
{
	int j;
	int x;
	int y;

	y = g_nw - g_ularg;
	j = g_nw - g_np;
	x = g_nw - j - g_ularg;
	if (g_nw > g_ularg && g_ularg >= g_np)
	{
		while (y > 0)
		{
			ft_putchar(' ');
			y--;
		}
	}
	while (j > 0 && g_nw > g_ularg && g_np > g_ularg)
	{
		ft_putchar(' ');
		j--;
	}
	print_x4(x);
}

void	print_x4(int x)
{
	if (g_uarg == 0 && g_np == 0)
		x++;
	while (x > 0 && g_ularg < g_np)
	{
		ft_putchar('0');
		x--;
	}
	if (g_uarg == 0 && g_np == 0)
	{
		ft_putchar(' ');
	}
	else
	{
		ft_xputnbr(g_uarg);
	}
}
