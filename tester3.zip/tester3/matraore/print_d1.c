/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/26 19:23:07 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/29 18:13:52 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_d1_1(void)
{
	g_bl = l_bigger() - g_larg;
	g_y = g_arg;
	if (g_nw < 0 && check_point() == 0)
	{
		ft_putnbr(g_arg);
		while (g_bl > 0)
		{
			ft_putchar(' ');
			g_bl--;
		}
	}
	else if (g_nw < 0 && check_point() != 0 && -g_nw > g_np)
	{
		print_d1_2();
		while (g_bl > 0)
		{
			ft_putchar(' ');
			g_bl--;
		}
	}
}

void	print_d1_2(void)
{
	if (g_arg < 0)
	{
		ft_putchar('-');
		g_arg = g_arg * (-1);
	}
	if (g_larg <= g_np)
	{
		g_x = g_np - g_larg;
		if (g_y < 0)
		{
			g_x++;
		}
	}
	print_d1_3();
}

void	print_d1_3(void)
{
	while (g_x > 0 && g_larg < g_np)
	{
		ft_putchar('0');
		g_x--;
		g_bl--;
	}
	if (g_onp == 0 && g_arg == 0)
		g_bl++;
	else
	{
		ft_putnbr(g_arg);
	}
}

int		l_bigger(void)
{
	int l;
	int nw;
	int np;

	l = 1;
	np = g_np;
	nw = g_nw;
	if (g_dneg == 1)
		np = 0;
	if (g_nw < 0)
		nw = nw * (-1);
	if (g_larg > nw && g_larg > np)
		l = l * g_larg;
	else if (np > nw && np > g_larg)
		l = l * np;
	else
		l = l * nw;
	return (l);
}
