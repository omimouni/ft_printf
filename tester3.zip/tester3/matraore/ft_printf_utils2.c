/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/09 21:45:38 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/29 03:49:18 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int		len_int(int n)
{
	int				l;
	unsigned int	nb;

	l = 1;
	if (n < 0)
	{
		l++;
		nb = (unsigned int)(-n);
	}
	else
		nb = (unsigned int)n;
	while (nb > 9)
	{
		nb /= 10;
		l++;
	}
	return (l);
}

int		len_unsint(unsigned int n)
{
	int				l;
	unsigned int	nb;

	l = 1;
	nb = (unsigned int)n;
	while (nb > 9)
	{
		nb /= 10;
		l++;
	}
	return (l);
}

int		ft_atoi(const char *s)
{
	int		i;
	int		x;
	long	nb;

	i = 0;
	x = 1;
	nb = 0;
	while (s[i] == ' ' || (s[i] >= 9 && s[i] <= 13))
		i++;
	if (s[i] == '-' || s[i] == '+')
	{
		if (s[i] == '-')
			x = -1;
		i++;
	}
	while (s[i] >= '0' && s[i] <= '9')
	{
		nb = nb * 10 + (s[i++] - '0');
		if (nb > 9223372036854775807 / 10)
		{
			nb = (x == -1) ? 0 : -1;
			break ;
		}
	}
	return (nb * x);
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	i;
	char	*dest;

	i = 0;
	dest = (char *)malloc((len + 1) * sizeof(char));
	if (!dest)
		return (NULL);
	if (!s)
		return (NULL);
	if ((size_t)start > ft_strlen(s))
		return (ft_strdup(""));
	while (len > i && s[i] != '\0')
	{
		dest[i] = s[start + i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

void	ft_uputnbr(unsigned int n)
{
	unsigned int nb;

	nb = n;
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
		ft_putchar((nb % 10) + '0');
	}
	else
		ft_putchar(nb + '0');
}
