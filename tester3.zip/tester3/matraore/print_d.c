/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/24 22:28:32 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 04:01:03 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_d(void)
{
	g_larg = len_int(g_arg);
	g_nnw = g_nw;
	g_l = l_bigger() - g_larg;
	if (g_nw < 0)
		g_nnw = -g_nnw;
	print_d2();
	if (g_nw > 0 && (check_point() == 0 || g_dneg == 1))
	{
		if (g_arg < 0 && (*g_str == '0' || g_dzero == 1))
		{
			ft_putchar('-');
			g_arg = -g_arg;
		}
		while (g_l > 0 && g_larg < g_nw)
		{
			(*g_str == '0' || g_dzero == 1) ? ft_putchar('0') : ft_putchar(' ');
			g_l--;
		}
		ft_putnbr(g_arg);
	}
	else if (g_nw > 0 && check_point() != 0 && g_nw > g_np)
		print_d3();
	print_d1_1();
}

void	print_d2(void)
{
	if (ft_strlen(g_str) == 0 || g_dexz == 1)
	{
		ft_putnbr(g_arg);
	}
	if (check_point() != 0 && (g_np >= g_nnw))
	{
		if (g_arg < 0)
		{
			ft_putchar('-');
			g_arg = g_arg * (-1);
			g_l = g_l + 1;
		}
		while ((g_l > 0 && g_larg < g_np))
		{
			ft_putchar('0');
			g_l--;
		}
		ft_putnbr(g_arg);
	}
}

void	print_d3(void)
{
	int j;
	int x;
	int y;

	y = g_nw - g_larg;
	j = g_nw - g_np;
	if (g_arg < 0)
		j--;
	x = g_nw - j - g_larg;
	if (g_nw > g_larg && g_larg >= g_np)
	{
		while (y > 0)
		{
			ft_putchar(' ');
			y--;
		}
	}
	while (j > 0 && g_nw > g_larg && g_np > g_larg)
	{
		ft_putchar(' ');
		j--;
	}
	print_d4(x);
}

void	print_d4(int x)
{
	if (g_arg < 0)
	{
		ft_putchar('-');
		g_arg = g_arg * (-1);
	}
	if (g_arg == 0 && g_np == 0)
		x++;
	while (x > 0 && g_larg < g_np)
	{
		ft_putchar('0');
		x--;
	}
	if (g_arg == 0 && g_np == 0)
	{
		ft_putchar(' ');
	}
	else
	{
		ft_putnbr(g_arg);
	}
}
