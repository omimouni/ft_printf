/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/26 19:23:07 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/29 18:40:08 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_u1_1(void)
{
	g_ubl = l_ubigger() - g_ularg;
	g_uy = g_uarg;
	if (g_nw < 0 && check_point() == 0)
	{
		ft_uputnbr(g_uarg);
		while (g_ubl > 0)
		{
			ft_putchar(' ');
			g_ubl--;
		}
	}
	else if (g_nw < 0 && check_point() != 0 && -g_nw > g_np)
	{
		print_u1_2();
		while (g_ubl > 0)
		{
			ft_putchar(' ');
			g_ubl--;
		}
	}
}

void	print_u1_2(void)
{
	if (g_ularg <= g_np)
		g_ux = g_np - g_ularg;
	while (g_ux > 0 && g_ularg < g_np)
	{
		ft_putchar('0');
		g_ux--;
		g_ubl--;
	}
	if (g_uonp == 0 && g_uarg == 0)
		g_ubl++;
	else
	{
		ft_uputnbr(g_uarg);
	}
}

int		l_ubigger(void)
{
	int l;
	int nw;
	int np;

	l = 1;
	np = g_np;
	nw = g_nw;
	if (g_uneg == 1)
		np = 0;
	if (g_nw < 0)
		nw = nw * (-1);
	if (g_ularg > nw && g_ularg > np)
		l = l * g_ularg;
	else if (np > nw && np > g_ularg)
		l = l * np;
	else
		l = l * nw;
	return (l);
}
