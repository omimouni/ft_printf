/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/09 01:42:21 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/31 20:36:59 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	collect_infos(char *fmt, va_list g_args)
{
	g_ii = 0;
	g_str = ft_substr(fmt, g_i, g_j - g_i);
	if (check_point() == 0)
	{
		g_w = g_str;
		skip_m(ft_strlen(g_str), fmt);
		g_nw = ft_atoi(g_str);
	}
	else
	{
		while (g_str[g_ii])
		{
			if (g_str[g_ii] == '.')
			{
				g_w = ft_substr(g_str, 0, g_ii);
				skip_m(g_ii, fmt);
				g_p = ft_substr(g_str, g_ii + 1,
				(int)ft_strlen(g_str) - (g_ii + 1));
				g_nw = ft_atoi(g_w);
				g_np = ft_atoi(g_p);
			}
			g_ii++;
		}
	}
	collect(g_args);
}

void	collect(va_list g_args)
{
	if (g_name_s == 'd' || g_name_s == 'i')
		etoile(g_args);
	else if (g_name_s == 'x' || g_name_s == 'X' || g_name_s == 'u')
		xetoile(g_args);
	else if (g_name_s == 's')
		setoile(g_args);
	else if (g_name_s == 'c')
		cetoile(g_args);
	else if (g_name_s == 'p')
		petoile(g_args);
	else if (g_name_s == '%')
		prc_etoile(g_args);
	menu();
	if (check_point() == 1)
	{
		free(g_w);
		free(g_p);
	}
	free(g_str);
}

void	etoile(va_list g_args)
{
	if (check_etoile() == 1 && check_point() == 0)
	{
		g_nw = va_arg(g_args, int);
		etoile3();
	}
	else if (check_etoile() == 1 && check_point() != 0)
	{
		if (nb_etoile() == 2)
		{
			g_nw = va_arg(g_args, int);
			g_np = va_arg(g_args, int);
		}
		else if (nb_etoile() == 1)
		{
			if (g_str[0] == '*' || (g_str[1] == '*' && (g_str[0] == '-' ||
							g_str[0] == '0')))
				g_nw = va_arg(g_args, int);
			else
				g_np = va_arg(g_args, int);
		}
	}
	g_arg = va_arg(g_args, int);
	g_onp = g_np;
	etoile2();
}

void	skip_m(int x, char *fmt)
{
	int i;

	i = 0;
	if (ft_strlen(g_str) != 0 && (g_str[i] == '-' || g_str[i] == '0'))
	{
		while (g_str[i + 1] == '-' || g_str[i + 1] == '0')
		{
			if (g_str[i] != g_str[i + 1])
				g_t = 1;
			i++;
		}
		if (check_point() == 0)
		{
			free(g_str);
			g_str = ft_substr(fmt, g_i + i, x - i);
		}
		else
		{
			free(g_w);
			g_w = ft_substr(fmt, g_i + i, x - i);
		}
	}
}

void	etoile2(void)
{
	if (g_nw == 0 && g_np == 0 && g_arg == 0)
		g_exc = 1;
	if (check_etoile() == 1 && g_np < 0)
	{
		g_dneg = 1;
		g_np = 0;
	}
	if (g_str[0] == '0')
		g_dzero = 1;
	if (g_nw == 0 && ft_strlen(g_str) != 0 && check_point() == 0 &&
	(g_w[0] == '-' || g_w[0] == '0'))
		g_dexz = 1;
	if (ft_strlen(g_str) == 0 || g_dexz == 1)
		g_exc = 0;
}
