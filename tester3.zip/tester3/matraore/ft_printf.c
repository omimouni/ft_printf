/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/21 22:40:10 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/31 20:55:13 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_printf(const char *fmt, ...)
{
	va_list	g_args;
	int		j;

	reset();
	va_start(g_args, fmt);
	j = 0;
	while (fmt[j] && fmt[j] != '%')
	{
		ft_putchar(fmt[j]);
		j++;
	}
	while (fmt[j])
	{
		if (fmt[j] == '%')
		{
			g_i = j + 1;
			find_specifier((char *)fmt, g_args);
			if (fmt[j + g_lprc + 1] == '%')
				j += g_lprc + 1;
		}
		j++;
	}
	va_end(g_args);
	return (g_ret);
}
