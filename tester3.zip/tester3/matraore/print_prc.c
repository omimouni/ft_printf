/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_prc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/07 03:22:16 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/31 20:47:01 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_prc(void)
{
	g_prc_r = 1;
	while (g_nw > 1 && g_prcex == 0)
	{
		((*g_str == '0' || g_przero == 1)) ? ft_putchar('0') : ft_putchar(' ');
		g_nw--;
	}
	ft_putchar('%');
	while (g_nw < -1)
	{
		ft_putchar(' ');
		g_nw++;
	}
	g_lprc = ft_strlen(g_str);
}

void	prc_etoile(va_list g_args)
{
	prc_etoile2();
	if (check_etoile() == 1 && check_point() == 0)
		g_nw = va_arg(g_args, int);
	else if (check_etoile() == 1 && check_point() != 0)
	{
		if (nb_etoile() == 2)
		{
			g_nw = va_arg(g_args, int);
			g_np = va_arg(g_args, int);
		}
		else if (nb_etoile() == 1)
		{
			if (g_str[0] == '*' || (g_str[1] == '*' && (g_str[0] == '-' ||
							g_str[0] == '0')))
				g_nw = va_arg(g_args, int);
			else
				g_np = va_arg(g_args, int);
		}
	}
	if (g_str[0] == '0')
		g_przero = 1;
}

void	prc_etoile2(void)
{
	if (g_t == 1)
	{
		g_prcex = 1;
		if (g_nw > 0)
			g_nw = -g_nw;
		if (check_point() == 0)
			*g_str = '-';
	}
}
