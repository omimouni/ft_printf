/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/21 22:38:29 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 03:55:49 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <stdarg.h>
# include <stdio.h>

void	collect_infos(char *fmt, va_list g_args);
void	collect(va_list g_args);
void	reset(void);
void	etoile(va_list g_args);
void	etoile3(void);
void	skip_m(int x, char *fmt);
void	etoile2(void);
void	find_specifier(char *fmt, va_list g_args);
void	print_str(char *fmt);
void	ft_putchar(char c);
void	ft_putnbr(long n);
void	ft_putstr(char *s);
size_t	ft_strlen(const char *s);
char	*ft_strdup(const char *s1);
int		len_int(int n);
int		len_unsint(unsigned int n);
int		ft_atoi(const char *s);
char	*ft_substr(char const *s, unsigned int start, size_t len);
void	ft_uputnbr(unsigned int n);
void	ft_xputnbr(unsigned long n);
void	ft_pputnbr(unsigned long n);
char	l_hex(unsigned long nb);
char	lm_hex(unsigned long nb);
int		lx_arg(unsigned long x);
int		check_point(void);
int		check_etoile(void);
int		nb_etoile(void);
int		ft_printf(const char *fmt, ...);
void	menu(void);
void	print_c(void);
void	cetoile(va_list g_args);
void	print_d();
void	print_d2(void);
void	print_d3(void);
void	print_d4(int x);
void	print_d1_1(void);
void	print_d1_2(void);
void	print_d1_3(void);
int		l_bigger(void);
void	print_p(void);
void	print_p2(void);
void	print_p3(void);
void	print_p4(int x);
void	petoile(va_list g_args);
void	print_p1_1(void);
void	print_p1_2(void);
int		l_pbigger(void);
void	print_prc(void);
void	prc_etoile(va_list g_args);
void	prc_etoile2(void);
void	print_s(void);
void	print_s2(void);
void	print_s3(void);
void	setoile(va_list g_args);
void	setoile2(void);
void	print_u(void);
void	print_u2(void);
void	print_u3(void);
void	print_u4(int x);
void	print_u1_1(void);
void	print_u1_2(void);
void	reset2(void);
int		l_ubigger(void);
void	print_x(void);
void	xetoile3(void);
void	setoile3(void);
void	print_x2(void);
void	print_x3(void);
void	print_x4(int x);
void	print_x1_1(void);
void	print_x1_2(void);
void	xetoile(va_list g_args);
void	xetoile2(void);
int		specifiers(char c);

int					g_nw;
int					g_np;
char				*g_str;
int					g_lprc;
int					g_przero;
int					g_prc_r;
long				g_t;
int					g_prcex;
int					g_i;
int					g_j;
char				g_name_s;
long				g_arg;
int					g_larg;
unsigned int		g_uarg;
unsigned long		g_parg;
int					g_ularg;
char				*g_w;
char				*g_p;
int					g_exc;
int					g_dzero;
int					g_dneg;
int					g_onp;
char				*g_arg_s;
int					g_larg_s;
int					g_dexz;
int					g_ret;
int					g_pzero;
char				g_arg_c;
int					g_l;
int					g_nnw;
int					g_bl;
int					g_x;
int					g_y;
int					g_plarg;
int					g_pexc;
int					g_pexz;
unsigned int		g_ubl;
unsigned int		g_ux;
unsigned int		g_uy;
int					g_sexz;
int					g_sneg;
int					g_snull;
int					g_uzero;
int					g_uneg;
int					g_uexz;
int					g_uonp;
int					g_ii;

#endif
