/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/24 22:28:32 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/29 17:49:08 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_p(void)
{
	if (g_pzero == 1)
		g_plarg = 2;
	else
		g_plarg = lx_arg(g_parg) + 2;
	g_nnw = g_nw;
	g_l = l_ubigger() - g_plarg;
	if (g_nw < 0)
		g_nnw = -g_nnw;
	print_p2();
	if (g_nw > 0 && (check_point() == 0))
	{
		while (g_l > 0 && g_plarg < g_nw)
		{
			ft_putchar(' ');
			g_l--;
		}
		ft_pputnbr(g_parg);
	}
	else if (g_nw > 0 && check_point() != 0 && g_nw > g_np)
		print_p3();
	print_p1_1();
}

void	print_p2(void)
{
	if (ft_strlen(g_str) == 0 || g_pexz == 1)
	{
		ft_pputnbr(g_parg);
	}
	if (check_point() != 0 && g_np >= g_nnw)
	{
		ft_pputnbr(g_parg);
	}
}

void	print_p3(void)
{
	int j;
	int x;
	int y;

	y = g_nw - g_plarg;
	j = g_nw - g_np;
	x = g_nw - j - g_plarg;
	if (g_nw > g_plarg && g_plarg >= g_np)
	{
		while (y > 0)
		{
			ft_putchar(' ');
			y--;
		}
	}
	while (j > 0 && g_nw > g_plarg && g_np > g_plarg)
	{
		ft_putchar(' ');
		j--;
	}
	ft_pputnbr(g_parg);
}

void	print_p4(int x)
{
	while (x > 0 && g_plarg < g_np)
	{
		ft_putchar('0');
		x--;
	}
}

void	petoile(va_list g_args)
{
	if (nb_etoile() == 1)
	{
		g_nw = va_arg(g_args, int);
	}
	g_parg = (unsigned long)va_arg(g_args, void *);
	if (g_parg == 0 && check_point() == 1)
		g_pzero = 1;
	if (check_point() == 0 && check_etoile() == 1)
	{
		if (g_nw == 0)
			g_pexz = 1;
	}
	if (g_nw == 0 && ft_strlen(g_str) != 0 && check_point() == 0 &&
	(g_w[0] == '-' || g_w[0] == '0'))
		g_pexz = 1;
}
