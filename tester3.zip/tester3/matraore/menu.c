/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   menu.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/24 22:24:38 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 03:58:31 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	menu(void)
{
	if (g_exc != 1 && (g_name_s == 'd' || g_name_s == 'i'))
		print_d();
	else if (g_exc != 1 && g_name_s == 's')
		print_s();
	else if (g_name_s == 'c')
		print_c();
	else if (g_exc != 1 && g_name_s == 'u')
		print_u();
	else if (g_name_s == '%')
		print_prc();
	else if (g_exc != 1 && (g_name_s == 'x' || g_name_s == 'X'))
		print_x();
	else if (g_name_s == 'p')
		print_p();
}
