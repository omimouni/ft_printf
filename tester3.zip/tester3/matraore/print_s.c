/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_s.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/21 20:04:15 by yer-raki          #+#    #+#             */
/*   Updated: 2020/01/31 20:48:07 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_s(void)
{
	g_larg_s = ft_strlen(g_arg_s);
	g_nnw = g_nw;
	if (g_nw < 0)
		g_nnw = -g_nnw;
	if (ft_strlen(g_str) == 0)
	{
		ft_putstr(g_arg_s);
	}
	if ((check_point() == 0 || g_sneg == 1) && ft_strlen(g_str) != 0)
		print_s2();
	else if (check_point() != 0)
		print_s3();
	if (g_snull == 1)
	{
		free(g_arg_s);
		g_snull = 0;
	}
}

void	print_s2(void)
{
	if (g_larg_s >= g_nnw)
	{
		ft_putstr(g_arg_s);
	}
	if (g_nw < 0 && (g_nnw > g_larg_s))
	{
		ft_putstr(g_arg_s);
	}
	while (g_nnw > g_larg_s)
	{
		ft_putchar(' ');
		g_nnw--;
	}
	if (g_nw > 0 && (g_nw > g_larg_s))
	{
		ft_putstr(g_arg_s);
	}
}

void	print_s3(void)
{
	if (g_np < g_larg_s)
	{
		g_snull = 1;
		g_arg_s = ft_substr(g_arg_s, 0, g_np);
	}
	g_larg_s = ft_strlen(g_arg_s);
	if ((g_nw < 0 && (g_nnw > g_larg_s)) || g_larg_s >= g_nnw)
	{
		ft_putstr(g_arg_s);
	}
	while (g_nnw > g_larg_s)
	{
		ft_putchar(' ');
		g_nnw--;
	}
	if (g_nw > 0 && (g_nw > g_larg_s))
	{
		ft_putstr(g_arg_s);
	}
}

void	setoile(va_list g_args)
{
	if (check_etoile() == 1 && check_point() == 0 && ft_strlen(g_str) != 0)
	{
		g_nw = va_arg(g_args, int);
		setoile3();
	}
	else if (check_etoile() == 1 && check_point() != 0)
	{
		if (nb_etoile() == 2)
		{
			g_nw = va_arg(g_args, int);
			g_np = va_arg(g_args, int);
		}
		else if (nb_etoile() == 1)
		{
			if (g_str[0] == '*' || (g_str[1] == '*' && (g_str[0] == '-' ||
							g_str[0] == '0')))
				g_nw = va_arg(g_args, int);
			else
				g_np = va_arg(g_args, int);
		}
	}
	g_arg_s = va_arg(g_args, char *);
	setoile2();
}

void	setoile2(void)
{
	if (g_nw == 0 && g_np == 0 && g_arg_s == 0)
		g_exc = 1;
	if (check_etoile() == 1 && g_np < 0)
	{
		g_sneg = 1;
		g_np = 0;
	}
	if (g_nw == 0 && ft_strlen(g_str) != 0 && check_point() == 0 &&
	(g_w[0] == '-' || g_w[0] == '0'))
		g_sexz = 1;
	if (ft_strlen(g_str) == 0 || g_sexz == 1)
		g_exc = 0;
	if (g_arg_s == NULL)
	{
		g_snull = 1;
		g_arg_s = ft_substr("(null)", 0, 6);
	}
}
