/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_x.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/07 04:26:22 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 03:58:58 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	ft_xputnbr(unsigned long n)
{
	unsigned long nb;

	nb = n;
	if (nb >= 16)
	{
		ft_xputnbr(nb / 16);
		if (g_name_s == 'x' || g_name_s == 'p')
			ft_putchar(l_hex((nb % 16)));
		else if (g_name_s == 'X')
			ft_putchar(lm_hex((nb % 16)));
	}
	else
	{
		if (g_name_s == 'x' || g_name_s == 'p')
			ft_putchar(l_hex((nb % 16)));
		else if (g_name_s == 'X')
			ft_putchar(lm_hex((nb % 16)));
	}
}

void	ft_pputnbr(unsigned long n)
{
	if (g_pzero == 1)
		ft_putstr("0x");
	else
	{
		ft_putstr("0x");
		ft_xputnbr((unsigned long)n);
	}
}

char	l_hex(unsigned long nb)
{
	if (nb == 10)
		return ('a');
	else if (nb == 11)
		return ('b');
	else if (nb == 12)
		return ('c');
	else if (nb == 13)
		return ('d');
	else if (nb == 14)
		return ('e');
	else if (nb == 15)
		return ('f');
	else
		return (nb + '0');
}

char	lm_hex(unsigned long nb)
{
	if (nb == 10)
		return ('A');
	else if (nb == 11)
		return ('B');
	else if (nb == 12)
		return ('C');
	else if (nb == 13)
		return ('D');
	else if (nb == 14)
		return ('E');
	else if (nb == 15)
		return ('F');
	else
		return (nb + '0');
}

int		lx_arg(unsigned long x)
{
	int l;

	l = 1;
	while (x >= 16)
	{
		x = x / 16;
		l++;
	}
	return (l);
}
