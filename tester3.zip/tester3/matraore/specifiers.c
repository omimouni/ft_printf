/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_width.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 18:08:49 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 04:03:52 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int		specifiers(char c)
{
	if (c == 'c' || c == 's' || c == 'p' || c == 'd' || c == 'i' || c == 'u'
			|| c == 'x' || c == 'X' || c == '%')
		return (1);
	else
		return (0);
}

void	reset(void)
{
	g_nw = 0;
	g_np = 0;
	g_str = NULL;
	g_lprc = 0;
	g_przero = 0;
	g_prc_r = 0;
	g_t = 0;
	g_prcex = 0;
	g_i = 0;
	g_j = 0;
	g_name_s = '\0';
	g_arg = 0;
	g_larg = 0;
	g_uarg = 0;
	g_parg = 0;
	g_ularg = 0;
	g_w = NULL;
	g_p = NULL;
	g_exc = 0;
	g_dzero = 0;
	g_dneg = 0;
	g_onp = 0;
	g_arg_s = NULL;
	g_larg_s = 0;
	reset2();
}

void	reset2(void)
{
	g_dexz = 0;
	g_ret = 0;
	g_pzero = 0;
	g_arg_c = '\0';
	g_l = 0;
	g_nnw = 0;
	g_bl = 0;
	g_x = 0;
	g_y = 0;
	g_plarg = 0;
	g_pexc = 0;
	g_pexz = 0;
	g_ubl = 0;
	g_ux = 0;
	g_uy = 0;
	g_sexz = 0;
	g_sneg = 0;
	g_snull = 0;
	g_uzero = 0;
	g_uneg = 0;
	g_uexz = 0;
	g_uonp = 0;
	g_ii = 0;
}

void	setoile3(void)
{
	if (g_nw == 0)
		g_sexz = 1;
	if (g_nw == 0 && g_arg_s == 0)
		g_exc = 1;
}

void	etoile3(void)
{
	if (g_nw == 0)
		g_dexz = 1;
	if (g_nw == 0 && g_arg == 0)
		g_exc = 1;
}
