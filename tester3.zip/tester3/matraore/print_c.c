/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_c.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yer-raki <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/01 18:53:21 by yer-raki          #+#    #+#             */
/*   Updated: 2020/02/06 03:59:45 by yer-raki         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	print_c(void)
{
	if (g_nw >= 0)
	{
		while (g_nw - 1 > 0 && g_nw != 0)
		{
			ft_putchar(' ');
			g_nw--;
		}
		ft_putchar(g_arg_c);
	}
	else if (g_nw < 0)
	{
		ft_putchar(g_arg_c);
		while (g_nw + 1 < 0)
		{
			ft_putchar(' ');
			g_nw++;
		}
	}
}

void	cetoile(va_list g_args)
{
	if (nb_etoile() == 1)
		g_nw = va_arg(g_args, int);
	g_arg_c = va_arg(g_args, int);
}
